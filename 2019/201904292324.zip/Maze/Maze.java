import java.util.ArrayList;
import java.util.List;

public class Maze {

    private List<List<Point>> points = new ArrayList<>();
    private int col;
    private int row;

    public List<List<Point>> getPoints() {
        return points;
    }

    public void setPoints(List<List<Point>> points) {
        this.points = points;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public Point getPoint(int x, int y) {
        return points.get(x).get(y);
    }

    public String render() {
        StringBuilder mazeText = new StringBuilder();
        points.forEach(list -> {
            list.forEach(point -> mazeText.append(point.getText() + " "));
            mazeText.deleteCharAt(mazeText.length() - 1);
            mazeText.append("\n");
        });
        return mazeText.toString();
    }

}
