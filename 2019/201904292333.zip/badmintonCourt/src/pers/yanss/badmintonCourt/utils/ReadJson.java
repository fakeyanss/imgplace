package pers.yanss.badmintonCourt.utils;

import java.io.FileReader;
import com.google.gson.*;

public class ReadJson {
	/**
	 * 传入json文件名，解析json数据，将需要的信息保存到一个一维数组str中
	 * 
	 * @param fileName
	 * @return str
	 * @throws Exception
	 */
	public String[] Read(String fileName) throws Exception {
		// 创建json解析器
		JsonParser parser = new JsonParser();
		String[] str;
		JsonObject object = (JsonObject) parser.parse(new FileReader("resource/" + fileName + ".json"));
		JsonArray scanIn = object.getAsJsonArray("scanIn");
		str = new String[scanIn.size()];
		for (int i = 0; i < scanIn.size(); i++) {
			JsonObject _scanIn = scanIn.get(i).getAsJsonObject();
			str[i] = _scanIn.get("str").toString().replaceAll("\"", "");
		}
		return str;
	}
}
