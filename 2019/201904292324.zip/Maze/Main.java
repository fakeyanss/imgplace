import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        @SuppressWarnings("resource")
        Scanner input = new Scanner(System.in);
        StringBuilder command = new StringBuilder();
        // get command line input, only 2 or 3 lines
        command.append(input.nextLine().trim());
        command.append("\n");
        command.append(input.nextLine().trim());
        if (input.hasNextLine()) {
            command.append("\n");
            command.append(input.nextLine().trim());
        }
        Maze maze = MazeFactory.create(command.toString());
        System.out.println(maze.render());
    }

}
