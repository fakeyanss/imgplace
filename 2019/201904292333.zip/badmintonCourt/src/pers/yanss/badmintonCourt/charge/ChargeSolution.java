package pers.yanss.badmintonCourt.charge;

import pers.yanss.badmintonCourt.utils.DateUtils;
import pers.yanss.badmintonCourt.utils.PrintBill;
import pers.yanss.badmintonCourt.utils.ReadJson;
import pers.yanss.badmintonCourt.utils.TextToFile;

public class ChargeSolution {
	static String FILE = "data2";// 输入信息储存到了json文件中，这里只需改变json文件名即可改变输入信息
	static String txt = "";// 输出信息保存到字符串txt中，最后将txt字符串信息写保存到一个文本文件中

	public static void main(String[] args) throws Exception {
		ReadJson json = new ReadJson();
		String[] data = json.Read(FILE);
		String[][] str = new String[data.length][7];// data每个元素以"
													// "切分后最大长度为5，加上星期几和两个标志位后长度为7
		DateUtils date = new DateUtils();
		str = transArray(str, data);
		// System.out.println(date.dayForWeek("2017-09-10"));
		// System.out.println(str[2].split(" ")[0]);
		for (int i = 0; i < str.length; i++) {
			System.out.println(data[i]);
			txt += data[i] + "\r\n";
			if (str[i][0].startsWith("U")) {
				if (date.isValidDate(str[i][1])) {
					if (date.isValidTime(str, i) == 1) {
						if (str[i][3].equals("A") || str[i][3].equals("B") || str[i][3].equals("C")
								|| str[i][3].equals("D")) {
							if (str[i][4].equals("C") || str[i][4].equals(" ")) {
								System.out.println("> Success: the booking is accepted!");
								txt += "> Success: the booking is accepted!" + "\r\n";
							} else {
								printInvalid();
							}
						} else {
							printInvalid();
						}
					} else if (date.isValidTime(str, i) == 2) {
						printInvalid();
					} else if (date.isValidTime(str, i) == 3) {
						System.out.println("> Error: the booking conflicts with existing bookings!");
						txt += "> Error: the booking conflicts with existing bookings!" + "\r\n";
					} else {
						System.out.println("> Error: the booking being cancelled does not exist!");
						txt += "> Error: the booking being cancelled does not exist!" + "\r\n";
					}
				} else {
					str[i][5] = "0";
					printInvalid();
				}
			} else {
				str[i][5] = "0";
				printInvalid();
			}
		}
		PrintBill printBill = new PrintBill();
		txt = printBill.Print(str, txt);
		TextToFile textToFile = new TextToFile();
		textToFile.toFile("bill.txt", txt);
	}

	/**
	 * 打印不合法的输出语句
	 */
	private static void printInvalid() {
		System.out.println("> Error: the booking is invalid!");
		txt += "> Error: the booking is invalid!" + "\r\n";
	}

	/**
	 * 将一维数组每个元素以" "切分，转化为二维数组,并在每行后面加上两个标志位 第一个标志位，1表示成功预订，0表示预订失败或取消预订
	 * 第二个标志位，1表示取消订单成功，0表示没有取消订单
	 * 
	 * @param str
	 *            二维数组
	 * @param data
	 *            一维数组
	 * @return str 转化后的二维数组
	 * @throws Exception
	 */
	private static String[][] transArray(String[][] str, String[] data) throws Exception {
		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < str[0].length; j++) {
				if (data[i].split(" ").length > j) {
					str[i][j] = data[i].split(" ")[j];
				} else if (j == 4) {
					str[i][j] = " ";
				} else if (j == 5) {
					str[i][j] = "1";
				} else {
					str[i][j] = "0";
				}
			}
		}
		return str;
	}
}
