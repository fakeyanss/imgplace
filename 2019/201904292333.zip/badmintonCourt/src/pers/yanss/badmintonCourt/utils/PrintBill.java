package pers.yanss.badmintonCourt.utils;

public class PrintBill {
	static int total = 0;

	/**
	 * 打印输出账单信息
	 * 
	 * @param str
	 *            保存输入信息的字符串数组
	 * @param txt
	 *            保存输出信息的字符串
	 * @return txt
	 * @throws Exception
	 */
	public String Print(String[][] str, String txt) throws Exception {
		System.out.println();
		txt += "\r\n";
		System.out.println("> 收入汇总");
		txt += "> 收入汇总" + "\r\n";
		System.out.println("> ---");
		txt += "> ---" + "\r\n";
		System.out.println("> 场地:A");
		txt += "> 场地:A" + "\r\n";
		txt = Court("A", str, txt);
		System.out.println(">");
		txt += ">" + "\r\n";
		System.out.println("> 场地:B");
		txt += "> 场地:B" + "\r\n";
		txt = Court("B", str, txt);
		System.out.println(">");
		txt += ">" + "\r\n";
		System.out.println("> 场地:C");
		txt += "> 场地:C" + "\r\n";
		txt = Court("C", str, txt);
		System.out.println(">");
		txt += ">" + "\r\n";
		System.out.println("> 场地:D");
		txt += "> 场地:D" + "\r\n";
		txt = Court("D", str, txt);
		System.out.println("> ---");
		txt += "> ---" + "\r\n";
		System.out.println("> 总计: " + total + " 元");
		txt += "> 总计: " + total + " 元" + "\r\n";
		return txt;
	}

	/**
	 * 根据羽毛球场地输出账单信息
	 * 
	 * @param type
	 *            羽毛球场地，可以为A,B,C,D
	 * @param str
	 *            保存输入信息的字符串数组
	 * @param txt
	 *            保存输出信息的字符串
	 * @return txt
	 * @throws Exception
	 */
	private static String Court(String type, String[][] str, String txt) throws Exception {
		DateUtils dateUtils = new DateUtils();
		int money = 0;
		int subtotal = 0;
		for (int i = 0; i < str.length; i++) {
			if (str[i][3].equals(type)) {
				int m = Integer.parseInt(str[i][2].split("~")[0].split(":")[0]);
				int n = Integer.parseInt(str[i][2].split("~")[1].split(":")[0]);
				if (str[i][5].equals("1")) {
					money = Bill(dateUtils.dayForWeek(str[i][1]), m, n);
					subtotal += money;
					total += subtotal;
					System.out.println("> " + str[i][1] + " " + str[i][2] + " " + money + " 元");
					txt += "> " + str[i][1] + " " + str[i][2] + " " + money + " 元" + "\r\n";

				} else if (str[i][5].equals("0") && str[i][6].equals("1")) {
					money = Bill(dateUtils.dayForWeek(str[i][1]), m, n) / 2;
					subtotal += money;
					System.out.println("> " + str[i][1] + " " + str[i][2] + " 违约金 " + money + " 元");
					txt += "> " + str[i][1] + " " + str[i][2] + " 违约金 " + money + " 元" + "\r\n";
				}
			}
		}
		System.out.println("> 小计: " + subtotal + " 元");
		txt += "> 小计: " + subtotal + " 元" + "\r\n";
		return txt;
	}

	/**
	 * 根据预订时间，求出消费金额。 首先判断星期几，再对开始时间进行划分，然后对结束时间进行划分，最后根据单位时长金额和时长求出消费金额
	 * 
	 * @param day
	 *            日期对应的星期几
	 * @param timeBegin
	 *            预订时间的起始时间
	 * @param timeOver
	 *            预订时间的结束时间
	 * @return money 消费金额
	 */
	private static int Bill(int day, int timeBegin, int timeOver) {
		int money = 0;
		if (day >= 1 && day <= 5) {
			if (timeBegin < 12) {
				if (timeOver < 12) {
					money = 30 * (timeOver - timeBegin);
				} else if (timeOver >= 12 && timeOver < 18) {
					money = 30 * (12 - timeBegin) + 50 * (timeOver - 12);
				} else if (timeOver >= 18 && timeOver < 20) {
					money = 30 * (12 - timeBegin) + 50 * (18 - 12) + 80 * (timeOver - 18);
				} else {
					money = 30 * (12 - timeBegin) + 50 * (18 - 12) + 80 * (20 - 18) + 60 * (timeOver - 20);
				}
			} else if (timeBegin >= 12 && timeBegin < 18) {
				if (timeOver < 18) {
					money = 50 * (timeOver - timeBegin);
				} else if (timeOver >= 18 && timeOver < 20) {
					money = 50 * (18 - timeBegin) + 80 * (timeOver - 18);
				} else {
					money = 50 * (18 - timeBegin) + 80 * (20 - 18) + 60 * (timeOver - 20);
				}
			} else if (timeBegin >= 18 && timeBegin < 20) {
				if (timeOver <= 20) {
					money = 80 * (timeOver - timeBegin);
				} else {
					money = 80 * (20 - timeBegin) + 60 * (timeOver - 20);
				}
			} else {
				money = 60 * (timeOver - timeBegin);
			}
		} else {
			if (timeBegin < 12) {
				if (timeOver < 12) {
					money = 40 * (timeOver - timeBegin);
				} else if (timeOver >= 12 && timeOver < 18) {
					money = 40 * (12 - timeBegin) + 50 * (timeOver - 12);
				} else {
					money = 40 * (12 - timeBegin) + 50 * (18 - 12) + 60 * (timeOver - 18);
				}
			} else if (timeBegin >= 12 && timeBegin < 18) {
				if (timeOver < 18) {
					money = 50 * (timeOver - timeBegin);
				} else {
					money = 50 * (18 - timeBegin) + 60 * (timeOver - 18);
				}
			} else {
				money = 60 * (timeOver - timeBegin);
			}
		}
		return money;
	}

}
