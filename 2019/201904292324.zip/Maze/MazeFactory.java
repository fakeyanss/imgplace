import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javafx.util.Pair;

public class MazeFactory {

    public static Maze create(String command) {
        String[] cmds = command.split("\n");
        // get maze size
        int[] rowAndCol = checkFirstLineInput(cmds[0]);
        Maze maze = init(rowAndCol[0], rowAndCol[1]);
        // get wall which is waited to be set to road
        List<Point> walls = checkSecondLineInput(cmds[1]);
        maze = connectRoad(maze, walls);
        // set robot end point
        if (cmds.length > 2) {
            Pair<Point, List<String>> robotAndMove = checkThirdLineInput(cmds[2]);
            maze = setRobot(robotAndMove, maze);
        }
        return maze;
    }

    // get initial maze wall and road
    private static Maze init(int row, int col) {
        Maze maze = new Maze();
        List<List<Point>> points = new ArrayList<>();
        // if number of cells is 3 * 3, then number of all the elements is 7 * 7
        for (int i = 0; i < row * 2 + 1; i++) {
            List<Point> tmPoints = new ArrayList<>();
            for (int j = 0; j < col * 2 + 1; j++) {
                Point point = new Point(i, j);
                if (i % 2 == 0 || j % 2 == 0) {
                    point.setText(Constant.MAZE_WALL);
                } else {
                    point.setText(Constant.MAZE_ROAD);
                }
                tmPoints.add(point);
            }
            points.add(tmPoints);
        }
        maze.setPoints(points);
        return maze;
    }

    // set wall to road
    private static Maze connectRoad(Maze maze, List<Point> walls) {
        walls.forEach(wall -> maze.getPoints().get(wall.getX()).get(wall.getY()).setText(Constant.MAZE_ROAD));
        return maze;
    }

    // check the first input command line, and return maze size
    private static int[] checkFirstLineInput(String cmd) {
        String[] rowAndCol = cmd.split(" ");
        if (rowAndCol.length != 2) {
            System.out.println(Constant.INCORRECT_COMMAND_FORMAT);
            System.exit(0);
        }
        int row = -1;
        int col = -1;
        try {
            row = Integer.parseInt(rowAndCol[0]);
            col = Integer.parseInt(rowAndCol[1]);
        } catch (Exception e) {
            System.out.println(Constant.INVALID_NUMBER_FORMAT);
            System.exit(1);
        }
        if (row < 0 || col < 0) {
            System.out.println(Constant.NUMBER_OUT_OF_RANGE);
            System.exit(0);
        }
        return new int[] { row, col };
    }

    // check the second input command line, and return a wall point list
    private static List<Point> checkSecondLineInput(String cmd) {
        List<Point> walls = new ArrayList<>();
        String[] roadAndRoad = cmd.split(";");
        Arrays.asList(roadAndRoad).forEach(twoRoads -> {
            String[] roads = twoRoads.split(" ");
            if (roads.length != 2) {
                System.out.println(Constant.INCORRECT_COMMAND_FORMAT);
                System.exit(0);
            }
            String[] road0 = roads[0].split(",");
            String[] road1 = roads[1].split(",");
            if (road0.length != 2 || road1.length != 2) {
                System.out.println(Constant.INCORRECT_COMMAND_FORMAT);
                System.exit(0);
            }
            int wallX = -1, wallY = -1;
            int road0X = -1, road0Y = -1, road1X = -1, road1Y = -1;
            try {
                road0X = Integer.parseInt(road0[0]);
                road0Y = Integer.parseInt(road0[1]);
                road1X = Integer.parseInt(road1[0]);
                road1Y = Integer.parseInt(road1[1]);
            } catch (NumberFormatException e) {
                System.out.println(Constant.INVALID_NUMBER_FORMAT);
                System.exit(1);
            }
            if (road0X == road1X && Math.abs(road0Y - road1Y) == 1) {
                // transfer cell coordinate to maze point coordinate, such as cell(0,1) ->
                // point(1,3)
                wallX = road0X * 2 + 1;
                wallY = road0Y + road1Y + 1;
            } else if (Math.abs(road0X - road1X) == 1 && road0Y == road1Y) {
                wallX = road0X + road1X + 1;
                wallY = road0Y * 2 + 1;
            } else {
                System.out.println(Constant.MAZE_FORMAT_ERROR);
                System.exit(0);
            }
            walls.add(new Point(wallX, wallY));
        });
        return walls;
    }

    // check the third input command line, and return maze size
    private static Pair<Point, List<String>> checkThirdLineInput(String cmd) {
        String[] cellAndMove = cmd.split(" ");
        String[] cell = cellAndMove[0].split(",");
        if (cell.length != 2) {
            System.out.println(Constant.INCORRECT_COMMAND_FORMAT);
            System.exit(0);
        }
        int x = -1, y = -1;
        try {
            x = Integer.parseInt(cell[0]) * 2 + 1;
            y = Integer.parseInt(cell[1]) * 2 + 1;
        } catch (NumberFormatException e) {
            System.out.println(Constant.INVALID_NUMBER_FORMAT);
            System.exit(1);
        }
        if (x < 0 || y < 0) {
            System.out.println(Constant.NUMBER_OUT_OF_RANGE);
            System.exit(0);
        }
        Point point = new Point(x, y);
        if (cellAndMove.length == 2) {
            String[] move = cellAndMove[1].split("|");
            return new Pair<>(point, Arrays.asList(move));
        } else {
            return new Pair<>(point, null);
        }
    }

    // set the robot move to end point
    private static Maze setRobot(Pair<Point, List<String>> robotAndMove, Maze maze) {
        Point robot = robotAndMove.getKey();
        Point point = maze.getPoint(robot.getX(), robot.getY());
        if (point.getText().equals(Constant.MAZE_WALL)) {
            return maze;
        } else {
            return getEndPoint(robot, robotAndMove.getValue(), maze);
        }
    }

    // get end point by move command
    private static Maze getEndPoint(Point robot, List<String> move, Maze maze) {
        if (move != null) {
            for (String m : move) {
                Point tmpPoint = maze.getPoint(robot.getNextPoint(m).getX(), robot.getNextPoint(m).getY());
                if (tmpPoint.getText().equals(Constant.MAZE_ROAD)) {
                    robot = robot.getNextPoint(m);
                } else {
                    break;
                }
            }
        }
        maze.getPoint(robot.getX(), robot.getY()).setText(Constant.MAZE_ROBOT);
        return maze;
    }

}
