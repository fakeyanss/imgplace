public final class Constant {

    public static final String MAZE_ROAD = "[R]";
    public static final String MAZE_WALL = "[W]";
    public static final String MAZE_ROBOT = "[*]";

    public static final String ROBOT_MOVE_UP = "W";
    public static final String ROBOT_MOVE_LEFT = "A";
    public static final String ROBOT_MOVE_DOWN = "S";
    public static final String ROBOT_MOVE_RIGHT = "D";

    public static final String INVALID_NUMBER_FORMAT = "InValid number format.";
    public static final String NUMBER_OUT_OF_RANGE = "Number out of range.";
    public static final String INCORRECT_COMMAND_FORMAT = "Incorrect command format.";
    public static final String MAZE_FORMAT_ERROR = "Maze format error.";

}
