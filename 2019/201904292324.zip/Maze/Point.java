public class Point {

    private int x;
    private int y;
    private String text;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Point getNextPoint(String move) {
        switch (move) {
        case Constant.ROBOT_MOVE_UP:
            return new Point(x - 1, y);
        case Constant.ROBOT_MOVE_LEFT:
            return new Point(x, y - 1);
        case Constant.ROBOT_MOVE_DOWN:
            return new Point(x + 1, y);
        case Constant.ROBOT_MOVE_RIGHT:
            return new Point(x, y + 1);
        default:
            System.out.println(Constant.INCORRECT_COMMAND_FORMAT);
            System.exit(0);
        }
        return null;
    }

    @Override
    public String toString() {
        return "Point:[x = " + x + ", y = " + y + ", text = " + text + "]";
    }

}
