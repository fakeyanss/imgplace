package pers.yanss.badmintonCourt.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateUtils {
	/**
	 * 判断日期格式是否合法，合法返回true
	 * 
	 * @param str
	 * @return convertSuccess
	 */
	public boolean isValidDate(String str) {
		boolean convertSuccess = true;
		// 指定日期格式为四位年/两位月份/两位日期，注意yyyy-MM-dd区分大小写
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			// 设置lenient为false.
			// 否则SimpleDateFormat会比较宽松地验证日期，比如2007/02/29会被接受，并转换成2007/03/01
			format.setLenient(false);
			format.parse(str);
		} catch (ParseException e) {
			// e.printStackTrace();
			// 如果throw java.text.ParseException或者NullPointerException，就说明格式不对
			convertSuccess = false;
		}
		return convertSuccess;
	}

	/**
	 * 判断预订时间是否合法，合法返回相应数据，1表示验证时间通过，2表示时间输入不合法，3表示预订时间和之前预订过的有冲突，4表示取消的订单不存在
	 * 
	 * @param str
	 *            预订时间段，如19:00~22:00
	 * @return convertSuccess
	 */
	public int isValidTime(String[][] str, int num) {
		int convertSuccess = 1;
		String[] time = str[num][2].split("~");
		if (Integer.parseInt(time[0].split(":")[0]) >= Integer.parseInt(time[1].split(":")[0])) {
			convertSuccess = 2;
			str[num][5] = "0";
		}
		if (!(time[0].split(":")[1].equals("00") && time[1].split(":")[1].equals("00"))) {
			convertSuccess = 2;
			str[num][5] = "0";
		}
		if (str[num][4].equals(" ")) {
			// 输入信息是下订单
			for (int i = 0; i < num; i++) {
				if (str[i][1].equals(str[num][1]) && str[i][3].equals(str[num][3]) && str[i][4].equals(" ")
						&& str[i][5].equals("1")) {
					// 如果预订时间段的起始时间小于之前预订信息的结束时间，或者预订时间段的结束时间大于之前预订信息的起始时间，则冲突
					if (Integer.parseInt(str[num][2].split("~")[0].split(":")[0]) < Integer
							.parseInt(str[i][2].split("~")[1].split(":")[0])) {
						convertSuccess = 3;
						str[num][5] = "0";

					}
					if (Integer.parseInt(str[num][2].split("~")[1].split(":")[0]) > Integer
							.parseInt(str[i][2].split("~")[0].split(":")[0])) {
						convertSuccess = 3;
						str[num][5] = "0";
					}
				}
			}
		} else {
			// 输入信息是取消订单
			for (int i = 0; i < num; i++) {
				if (str[i][1].equals(str[num][1]) && str[i][2].equals(str[num][2]) && str[i][3].equals(str[num][3])
						&& str[i][4].equals(" ") && str[i][5].equals("1")) {
					convertSuccess = 1;
					str[i][5] = "0";
					str[i][6] = "1";
					str[num][5] = "0";
					break;
				} else {
					str[num][5] = "0";
					convertSuccess = 4;
				}
			}
		}
		return convertSuccess;
	}

	/**
	 * 判断当前日期是星期几
	 * @param pTime 要判断的时间
	 * @return dayForWeek 判断结果
	 * @Exception 发生异常
	 */
	public int dayForWeek(String pTime) throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		c.setTime(format.parse(pTime));
		int dayForWeek = 0;
		if (c.get(Calendar.DAY_OF_WEEK) == 1) {
			dayForWeek = 7;
		} else {
			dayForWeek = c.get(Calendar.DAY_OF_WEEK) - 1;
		}
		return dayForWeek;
	}

}
