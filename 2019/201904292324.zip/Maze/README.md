# Maze 
## 介绍
代码有4个java文件, 介绍如下
```
Maze
 |----Point.java        实体类, 存储 maze 矩阵中每个点
 |----Maze.java         实体类, 存储 maze 矩阵的信息
 |----MazeFactory.java  maze工厂类, 包含命令的读取/检测/解析, maze相关操作
 |----Main.java         入口
```

## 运行
```
javac Main.java
java Main
3 3
0,1 0,2;0,0 1,0;0,1 1,1;0,2 1,2;1,0 1,1;1,1 1,2;1,1 2,1;1,2 2,2;2,0 2,1

# 其他测试用例
4 4
0,1 1,1;2,1 3,1
# 输出
[W] [W] [W] [W] [W] [W] [W] [W] [W]
[W] [R] [W] [R] [W] [R] [W] [R] [W]
[W] [W] [W] [R] [W] [W] [W] [W] [W]
[W] [R] [W] [R] [W] [R] [W] [R] [W]
[W] [W] [W] [W] [W] [W] [W] [W] [W]
[W] [R] [W] [R] [W] [R] [W] [R] [W]
[W] [W] [W] [R] [W] [W] [W] [W] [W]
[W] [R] [W] [R] [W] [R] [W] [R] [W]
[W] [W] [W] [W] [W] [W] [W] [W] [W]

3 a
0,1 1,1
# 输出
InValid number format.

-1 2
0,1 1,1
# 输出
Number out of range.

3 3
012345
# 输出
Incorrect command format.

3 3
0,1 2,1
# 输出
Maze format error.
```

## 思路
抽象问题内容, 发现要做的事就是读取命令输入和构建迷宫矩阵

细致分析一下, 有以下步骤

* 读取从第一行输入的命令, 先用 `MazeFactory` 的 `checkFirstLineInput()` 方法检测输入, 得到的结果可以构建初始的迷宫矩阵, 即这种, 共有九个 `[R]`, 在代码中是 `MazeFactory` 的 `init()` 方法.
```
[W] [W] [W] [W] [W] [W] [W]
[W] [R] [W] [R] [W] [R] [W]
[W] [W] [W] [W] [W] [W] [W]
[W] [R] [W] [R] [W] [R] [W]
[W] [W] [W] [W] [W] [W] [W]
[W] [R] [W] [R] [W] [R] [W]
[W] [W] [W] [W] [W] [W] [W]
```

* 然后读取第二行命令, 提取出一组组的Road, 如 `(0,1) (0,2)`, 由于这是在 cell 中的下标, 我们将它转变为 maze 矩阵的下标, 即`(1,3) (1,5)`, 这样就是可以连通的两个Road节点, 并且得到需要被转变为Road 的 Wall 节点`(1,4)`. 

    重复这样的操作, 可以得到一组需要被转变为Road 的 Wall节点的List, 在代码中是 `MazeFactory` 的 `checkSecondLineInput()` 方法, 此方法同时处理了对第二行命令输入的检测.

    然后将它们的节点信息`[W]`变为`[R]`, 即 `connectRoad()`

* 最后, 对 maze 矩阵信息进行打印输入, 即 `maze.render()`